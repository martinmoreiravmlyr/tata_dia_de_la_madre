document.getElementById('surveyForm').addEventListener('submit', function(event) {
    event.preventDefault();

    // Mostrar el loader al enviar el formulario
    const loader = document.getElementById('loader');
    loader.style.display = 'flex';

    // Objeto para contar los puntos de cada categoría
    const scores = {
        mimos: 0,
        belleza: 0,
        abrazo: 0,
        salud: 0,
        hogar: 0,
        innovacion: 0
    };

    // Sumar puntos de cada selección de respuesta en el formulario
    Array.from(document.querySelectorAll('.form-select')).forEach(select => {
        const category = select.value;
        if (scores.hasOwnProperty(category)) {
            scores[category] += 1;  // Aumenta en 1 el contador para la categoría seleccionada
        }
    });

    console.log(scores)

    // Encontrar la categoría con el máximo puntaje
    let maxCategory = Object.keys(scores).reduce((a, b) => scores[a] > scores[b] ? a : b);

    // Carga los productos filtrados por la categoría con mayor puntuación
    fetch('products_description.json')
        .then(response => response.json())
        .then(products => {
            let filteredProducts = products.filter(product => product.category === maxCategory);
            displayProducts(filteredProducts);

            // Ocultar el loader después de un segundo como mínimo
            setTimeout(function() {
                loader.style.display = 'none';
            }, 1000);
        });
});

function displayProducts(products) {
    const productList = document.getElementById('productList');
    productList.innerHTML = '';
    products.forEach(product => {
        productList.innerHTML += `
            <div class="col-md-3 col-12">
                <div class="card">
                    <div class="card-body">
                        <img class="card-img-top" src="${product.image}" alt="Imagen de ${product.name}">
                        <h5 class="card-title">${product.name}</h5>
                        <h6>${product.etiqueta}</h6>
                        <p>${product.description}</p>
                        <a href="${product.url}" class="buttonvermas"><img src="images/bag.png" alt="Icono Buscar" class="icono-btn">Ver en la tienda</a>
                    </div>
                </div>
            </div>`;
    });
}
